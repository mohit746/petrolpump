import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  RefreshControl,
  SafeAreaView,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';
import {useAuth} from '../services/AuthContext';
import {useData} from '../services/DataContext';
import {DashboardSummary} from '../types';

const DashboardScreen = () => {
  const {user, logout} = useAuth();
  const {isOffline, pendingSyncCount, forcSync} = useData();
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const {fetchDashboardData} = useData();

  const loadDashboard = async () => {
    try {
      const data = await fetchDashboardData();
      setSummary(data);
    } catch (error) {
      console.error('Dashboard error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadDashboard();
  }, []);

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboard();
  };

  const handleSync = async () => {
    try {
      await forcSync();
    } catch (error) {
      console.error('Sync error:', error);
    }
  };

  const StatCard = ({title, value, color = '#3b82f6', icon}: any) => (
    <View style={[styles.statCard, {backgroundColor: `${color}15`}]}>
      <Icon name={icon} size={24} color={color} />
      <Text style={[styles.statValue, {color}]}>{value}</Text>
      <Text style={styles.statTitle}>{title}</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.welcomeText}>
            Welcome, {user?.firstName || user?.username}
          </Text>
          <View style={styles.statusContainer}>
            <Text style={styles.roleText}>{user?.role}</Text>
            {isOffline && (
              <View style={styles.offlineBadge}>
                <Text style={styles.offlineText}>OFFLINE</Text>
              </View>
            )}
          </View>
        </View>
        <View style={styles.headerActions}>
          {pendingSyncCount > 0 && (
            <TouchableOpacity
              style={styles.syncButton}
              onPress={handleSync}
              disabled={isOffline}>
              <Icon name="sync" size={16} color="white" />
              <Text style={styles.syncText}>Sync ({pendingSyncCount})</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity onPress={logout} style={styles.logoutButton}>
            <Icon name="logout" size={20} color="#ef4444" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }>
        {/* Offline Alert */}
        {isOffline && (
          <View style={styles.alert}>
            <Icon name="wifi-off" size={20} color="#f59e0b" />
            <Text style={styles.alertText}>
              You are offline. Some features may be limited.
            </Text>
          </View>
        )}

        {/* Pending Sync Alert */}
        {pendingSyncCount > 0 && (
          <View style={styles.alert}>
            <Icon name="sync-problem" size={20} color="#3b82f6" />
            <Text style={styles.alertText}>
              {pendingSyncCount} item(s) pending sync. Data will be uploaded when online.
            </Text>
          </View>
        )}

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionButtons}>
            <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#22c55e'}]}>
              <Icon name="schedule" size={24} color="white" />
              <Text style={styles.actionButtonText}>Manage Shift</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionButton, {backgroundColor: '#f59e0b'}]}>
              <Icon name="edit-note" size={24} color="white" />
              <Text style={styles.actionButtonText}>Add Reading</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Summary Stats */}
        {summary && (
          <>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Today's Summary</Text>
              <View style={styles.statsGrid}>
                <StatCard
                  title="Expected Revenue"
                  value={`₹${(summary.todayStats?.expectedCash || 0).toLocaleString()}`}
                  color="#22c55e"
                  icon="currency-rupee"
                />
                <StatCard
                  title="Cash Collected"
                  value={`₹${(summary.todayStats?.totalCashCollected || 0).toLocaleString()}`}
                  color="#8b5cf6"
                  icon="account-balance-wallet"
                />
                <StatCard
                  title="Completed Shifts"
                  value={summary.todayStats?.completedShifts || 0}
                  color="#3b82f6"
                  icon="assessment"
                />
                <StatCard
                  title="Variance"
                  value={`₹${Math.abs(summary.todayStats?.totalVariance || 0).toLocaleString()}`}
                  color={(summary.todayStats?.totalVariance || 0) >= 0 ? '#22c55e' : '#ef4444'}
                  icon={(summary.todayStats?.totalVariance || 0) >= 0 ? 'trending-up' : 'trending-down'}
                />
              </View>
            </View>

            {/* Active Shifts */}
            {summary.activeShifts?.shifts?.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Active Shifts</Text>
                {summary.activeShifts.shifts.map((shift) => (
                  <View key={shift.id} style={styles.shiftCard}>
                    <Text style={styles.shiftName}>{shift.staffName}</Text>
                    <View style={styles.activeBadge}>
                      <Text style={styles.activeText}>IN PROGRESS</Text>
                    </View>
                  </View>
                ))}
              </View>
            )}

            {/* Recent Alerts */}
            {summary.alerts && summary.alerts.length > 0 && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Recent Alerts</Text>
                {summary.alerts.slice(0, 3).map((alert, index) => (
                  <View
                    key={index}
                    style={[
                      styles.alertCard,
                      {borderLeftColor: alert.type === 'excess' ? '#f59e0b' : '#ef4444'},
                    ]}>
                    <View style={styles.alertHeader}>
                      <Text style={styles.alertStaffName}>{alert.staffName}</Text>
                      <Text style={styles.alertTime}>
                        {new Date(alert.timestamp).toLocaleTimeString()}
                      </Text>
                    </View>
                    <Text style={styles.alertDetails}>
                      {alert.type === 'excess' ? 'Excess' : 'Shortage'}: ₹
                      {Math.abs(alert.variance).toLocaleString()} ({alert.variancePercentage}%)
                    </Text>
                  </View>
                ))}
              </View>
            )}
          </>
        )}

        {/* No Data State */}
        {!summary && !loading && (
          <View style={styles.noDataContainer}>
            <Icon name="dashboard" size={48} color="#9ca3af" />
            <Text style={styles.noDataTitle}>No dashboard data available</Text>
            <Text style={styles.noDataText}>
              Data will appear once you start using the system
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#3b82f6',
    paddingTop: 12,
    paddingBottom: 16,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  welcomeText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  statusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  roleText: {
    color: '#bfdbfe',
    fontSize: 14,
  },
  offlineBadge: {
    backgroundColor: '#ef4444',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    marginLeft: 8,
  },
  offlineText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  syncButton: {
    backgroundColor: '#f59e0b',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  syncText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  logoutButton: {
    padding: 8,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  alert: {
    backgroundColor: '#fef3c7',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 8,
  },
  alertText: {
    color: '#92400e',
    fontSize: 14,
    flex: 1,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 12,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#22c55e',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  actionButtonText: {
    color: 'white',
    fontSize: 14,
    fontWeight: '600',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    gap: 8,
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  statTitle: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center',
  },
  shiftCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  shiftName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
  },
  activeBadge: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  activeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  alertCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    marginBottom: 8,
  },
  alertHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  alertStaffName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
  },
  alertTime: {
    fontSize: 12,
    color: '#6b7280',
  },
  alertDetails: {
    fontSize: 14,
    color: '#6b7280',
  },
  noDataContainer: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  noDataTitle: {
    fontSize: 18,
    color: '#6b7280',
    marginTop: 16,
    marginBottom: 8,
  },
  noDataText: {
    fontSize: 14,
    color: '#9ca3af',
    textAlign: 'center',
  },
});

export default DashboardScreen;