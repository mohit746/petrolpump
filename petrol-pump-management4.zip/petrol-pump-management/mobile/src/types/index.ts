export interface User {
  id: string;
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  role: 'OWNER' | 'MANAGER' | 'SUPERVISOR' | 'CASHIER' | 'STAFF';
  isActive: boolean;
}

export interface Dispenser {
  id: string;
  name: string;
  unitNumber: string;
  fuelType: 'MS' | 'HSD' | 'LUBRICANT' | 'ENGINE_OIL_2T';
  ratePerLiter: number;
  isActive: boolean;
  lastReading: number;
}

export interface Shift {
  id: string;
  userId: string;
  staffName: string;
  startTime: string;
  endTime?: string;
  status: 'ACTIVE' | 'COMPLETED' | 'CANCELLED';
  notes?: string;
}

export interface Reading {
  id: string;
  dispensingUnitId: string;
  shiftId: string;
  previousReading: number;
  currentReading: number;
  fuelSold: number;
  ratePerLiter: number;
  expectedRevenue: number;
  cashCollected?: number;
  variance?: number;
  entryType: 'SHIFT_START' | 'SHIFT_END' | 'INTERMEDIATE' | 'EMERGENCY';
  enteredBy: string;
  notes?: string;
  timestamp: string;
}

export interface DashboardSummary {
  activeShifts: {
    count: number;
    shifts: Array<{
      id: string;
      staffName: string;
    }>;
  };
  todayStats: {
    completedShifts: number;
    totalCashCollected: number;
    expectedCash: number;
    totalVariance: number;
    variancePercentage: string;
  };
  fuelSales: Record<string, {
    totalLiters: number;
    totalRevenue: number;
  }>;
  alerts: Array<{
    variance: number;
    expectedCash: number;
    variancePercentage: string;
    timestamp: string;
    staffName: string;
    type: 'excess' | 'shortage';
  }>;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}