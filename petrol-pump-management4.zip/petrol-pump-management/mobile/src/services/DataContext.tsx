import React, {createContext, useContext, useReducer, useEffect, ReactNode} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import {useAuth} from './AuthContext';
import {Dispenser, Shift, Reading, DashboardSummary} from '../types';

interface DataState {
  dispensers: Dispenser[];
  currentShift: Shift | null;
  readings: Reading[];
  pendingReadings: any[];
  pendingSyncCount: number;
  isOffline: boolean;
  isLoading: boolean;
  error: string | null;
  lastSync: string | null;
}

interface DataContextType extends DataState {
  addReading: (reading: any) => Promise<{success: boolean; offline?: boolean; error?: string}>;
  forcSync: () => Promise<void>;
  fetchDashboardData: () => Promise<DashboardSummary | null>;
}

const initialState: DataState = {
  dispensers: [],
  currentShift: null,
  readings: [],
  pendingReadings: [],
  pendingSyncCount: 0,
  isOffline: false,
  isLoading: false,
  error: null,
  lastSync: null,
};

type DataAction =
  | {type: 'SET_LOADING'; payload: boolean}
  | {type: 'SET_ERROR'; payload: string | null}
  | {type: 'SET_OFFLINE'; payload: boolean}
  | {type: 'SET_DISPENSERS'; payload: Dispenser[]}
  | {type: 'SET_CURRENT_SHIFT'; payload: Shift | null}
  | {type: 'SET_READINGS'; payload: Reading[]}
  | {type: 'ADD_PENDING_READING'; payload: any}
  | {type: 'REMOVE_PENDING_READING'; payload: string}
  | {type: 'CLEAR_PENDING_READINGS'};

function dataReducer(state: DataState, action: DataAction): DataState {
  switch (action.type) {
    case 'SET_LOADING':
      return {...state, isLoading: action.payload};
    case 'SET_ERROR':
      return {...state, error: action.payload, isLoading: false};
    case 'SET_OFFLINE':
      return {...state, isOffline: action.payload};
    case 'SET_DISPENSERS':
      return {...state, dispensers: action.payload};
    case 'SET_CURRENT_SHIFT':
      return {...state, currentShift: action.payload};
    case 'SET_READINGS':
      return {...state, readings: action.payload};
    case 'ADD_PENDING_READING':
      return {
        ...state,
        pendingReadings: [...state.pendingReadings, action.payload],
        pendingSyncCount: state.pendingSyncCount + 1,
      };
    case 'REMOVE_PENDING_READING':
      return {
        ...state,
        pendingReadings: state.pendingReadings.filter(r => r.id !== action.payload),
        pendingSyncCount: Math.max(0, state.pendingSyncCount - 1),
      };
    case 'CLEAR_PENDING_READINGS':
      return {
        ...state,
        pendingReadings: [],
        pendingSyncCount: 0,
      };
    default:
      return state;
  }
}

const DataContext = createContext<DataContextType | undefined>(undefined);

interface DataProviderProps {
  children: ReactNode;
}

export function DataProvider({children}: DataProviderProps) {
  const [state, dispatch] = useReducer(dataReducer, initialState);
  const {api, isAuthenticated} = useAuth();

  // Monitor network connectivity
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(netState => {
      dispatch({type: 'SET_OFFLINE', payload: !netState.isConnected});
    });

    return unsubscribe;
  }, []);

  // Load initial data when authenticated
  useEffect(() => {
    if (isAuthenticated) {
      loadInitialData();
    }
  }, [isAuthenticated]); // loadInitialData is defined below

  const loadInitialData = async () => {
    try {
      dispatch({type: 'SET_LOADING', payload: true});
      
      // Load cached data first
      const cachedDispensers = await AsyncStorage.getItem('dispensers');
      if (cachedDispensers) {
        dispatch({type: 'SET_DISPENSERS', payload: JSON.parse(cachedDispensers)});
      }

      const cachedShift = await AsyncStorage.getItem('currentShift');
      if (cachedShift) {
        dispatch({type: 'SET_CURRENT_SHIFT', payload: JSON.parse(cachedShift)});
      }

      // If online, fetch fresh data
      if (!state.isOffline) {
        await syncData();
      }
    } catch (error) {
      console.error('Error loading initial data:', error);
      dispatch({type: 'SET_ERROR', payload: 'Failed to load data'});
    } finally {
      dispatch({type: 'SET_LOADING', payload: false});
    }
  };

  const syncData = async () => {
    try {
      // Fetch dispensers
      const dispensersResponse = await api.get('/dispensers');
      if (dispensersResponse.data.success) {
        const dispensers = dispensersResponse.data.data;
        dispatch({type: 'SET_DISPENSERS', payload: dispensers});
        await AsyncStorage.setItem('dispensers', JSON.stringify(dispensers));
      }

      // Fetch current shift
      const shiftResponse = await api.get('/shifts?action=current');
      if (shiftResponse.data.success) {
        const shift = shiftResponse.data.data;
        dispatch({type: 'SET_CURRENT_SHIFT', payload: shift});
        await AsyncStorage.setItem('currentShift', JSON.stringify(shift));
      }
    } catch (error) {
      console.error('Sync error:', error);
    }
  };

  const addReading = async (readingData: any) => {
    try {
      if (state.isOffline) {
        // Store offline
        const offlineReading = {
          id: Date.now().toString(),
          ...readingData,
          timestamp: new Date().toISOString(),
          offline: true,
        };

        dispatch({type: 'ADD_PENDING_READING', payload: offlineReading});
        await AsyncStorage.setItem(
          'pendingReadings',
          JSON.stringify([...state.pendingReadings, offlineReading])
        );

        return {success: true, offline: true};
      } else {
        // Send to server
        const response = await api.post('/readings', readingData);
        if (response.data.success) {
          return {success: true};
        } else {
          return {success: false, error: response.data.error};
        }
      }
    } catch (error: any) {
      console.error('Add reading error:', error);
      return {success: false, error: error.message};
    }
  };

  const forcSync = async () => {
    try {
      // Sync pending readings
      for (const reading of state.pendingReadings) {
        try {
          await api.post('/readings', reading);
          dispatch({type: 'REMOVE_PENDING_READING', payload: reading.id});
        } catch (error) {
          console.error('Error syncing reading:', error);
        }
      }

      // Refresh data
      await syncData();
    } catch (error) {
      console.error('Force sync error:', error);
      throw error;
    }
  };

  const fetchDashboardData = async (): Promise<DashboardSummary | null> => {
    try {
      if (state.isOffline) {
        return null;
      }

      const response = await api.get('/dashboard/summary');
      if (response.data.success) {
        return response.data.data;
      }
      return null;
    } catch (error) {
      console.error('Dashboard fetch error:', error);
      return null;
    }
  };

  const value: DataContextType = {
    ...state,
    addReading,
    forcSync,
    fetchDashboardData,
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

export function useData(): DataContextType {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}