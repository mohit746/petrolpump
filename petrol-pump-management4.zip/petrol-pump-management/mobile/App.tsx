/**
 * Petrol Pump Management App
 * React Native CLI Implementation
 *
 * @format
 */

import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {StatusBar} from 'react-native';
import {PaperProvider} from 'react-native-paper';
import {SafeAreaProvider} from 'react-native-safe-area-context';

// Screens
import LoginScreen from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import ReadingEntryScreen from './src/screens/ReadingEntryScreen';
import ShiftScreen from './src/screens/ShiftScreen';
import DispensersScreen from './src/screens/DispensersScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import ReportsScreen from './src/screens/ReportsScreen';

// Services and Context
import {AuthProvider, useAuth} from './src/services/AuthContext';
import {DataProvider} from './src/services/DataContext';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function TabNavigator() {
  const {user} = useAuth();

  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#3b82f6',
        tabBarInactiveTintColor: 'gray',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#ffffff',
          borderTopWidth: 1,
          borderTopColor: '#e5e7eb',
          paddingBottom: 5,
          paddingTop: 5,
          height: 60,
        },
      }}>
      <Tab.Screen 
        name="Dashboard" 
        component={DashboardScreen}
        options={{tabBarLabel: 'Dashboard'}}
      />
      <Tab.Screen 
        name="Shifts" 
        component={ShiftScreen}
        options={{tabBarLabel: 'Shifts'}}
      />
      <Tab.Screen 
        name="Readings" 
        component={ReadingEntryScreen}
        options={{tabBarLabel: 'Readings'}}
      />
      {(user?.role === 'OWNER' || user?.role === 'MANAGER') && (
        <Tab.Screen 
          name="Dispensers" 
          component={DispensersScreen}
          options={{tabBarLabel: 'Dispensers'}}
        />
      )}
      <Tab.Screen 
        name="Reports" 
        component={ReportsScreen}
        options={{tabBarLabel: 'Reports'}}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{tabBarLabel: 'Profile'}}
      />
    </Tab.Navigator>
  );
}

function AppNavigator() {
  const {isAuthenticated} = useAuth();

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        {!isAuthenticated ? (
          <Stack.Screen name="Login" component={LoginScreen} />
        ) : (
          <Stack.Screen name="Main" component={TabNavigator} />
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}

function App(): React.JSX.Element {
  return (
    <SafeAreaProvider>
      <PaperProvider>
        <AuthProvider>
          <DataProvider>
            <StatusBar barStyle="light-content" backgroundColor="#3b82f6" />
            <AppNavigator />
          </DataProvider>
        </AuthProvider>
      </PaperProvider>
    </SafeAreaProvider>
  );
}

export default App;
