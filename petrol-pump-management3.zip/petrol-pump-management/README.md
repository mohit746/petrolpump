# ⛽ FuelDesk — Petrol Pump Management Platform

> A multi-tenant SaaS platform for managing petrol pump operations across India.  
> Built with React (PWA) + Supabase (PostgreSQL + Auth + Edge Functions).

**Support:** +91-96406 20555 | mohitdwivedi746@gmail.com

---

## 📋 Table of Contents
1. [Platform Architecture](#1-platform-architecture)
2. [User Roles & Access Control](#2-user-roles--access-control)
3. [Feature Modules](#3-feature-modules)
4. [Database Schema](#4-database-schema)
5. [Tech Stack](#5-tech-stack)
6. [Project Structure](#6-project-structure)
7. [Environment Setup](#7-environment-setup)
8. [Running Locally](#8-running-locally)
9. [Deployment](#9-deployment)
10. [Database Migrations](#10-database-migrations)
11. [Onboarding a New Petrol Pump](#11-onboarding-a-new-petrol-pump)
12. [Role Quick Reference](#12-role-quick-reference-card)

---

## 1. Platform Architecture

```
PLATFORM_OWNER (mohitdwivedi746@gmail.com)
  │  Manages all pumps, subscriptions, features
  │
  ├── Pump A  ←── SUPER_ADMIN (pump owner / petrol pump malik)
  │               ├── ADMIN (manager / munshi)
  │               ├── ACCOUNTANT (finance / hisab)
  │               └── EMPLOYEE (pump staff / karmachari)
  │
  ├── Pump B  ←── SUPER_ADMIN
  │               └── ...
  └── Pump N  ←── ...
```

### Key Tenancy Rule
Every piece of operational data carries a `pump_id` FK.
Employees of Pump A can NEVER see data from Pump B.

---

## 2. User Roles & Access Control

### PLATFORM_OWNER — mohitdwivedi746@gmail.com
- Single account, system-level, no pump operations UI
- Create / update / suspend / delete petrol pumps
- Create SUPER_ADMIN accounts for each pump
- Set pump details: name, address, city, state, pincode, country, phone, email
- Subscription management: plan, monthly premium, expiry date
- Toggle WhatsApp and reports features per pump
- Record payment received, view MRR dashboard

### SUPER_ADMIN — Pump Owner
- Full employee management: add, edit, block, delete
- Approve / reject leave requests
- Lorry duty management
- Credit approval: approve customer credit settlements
- Daily meter readings and sales analytics
- Dashboard analytics: per-day, per-month, per-year
- Monthly payslip generation and WhatsApp delivery
- Pump settings: geo-fence, shift timing, WhatsApp credentials

### ADMIN — Pump Manager
- Shift handover and employee attendance view
- Approve leave plans
- Enter daily meter readings (8 nozzles: 4 MS petrol + 4 HSD diesel)
  - Previous day end reading auto-fetched
  - Today end reading entered → daily sale auto-calculated
- Lorry duty management
- Credit monitoring (view, not approve)
- View payslips (read-only)
- Cannot create/delete employees or change salaries

### ACCOUNTANT — Finance
- View all financial transactions
- Credit management: track credit given to customers
- Loans and salary deductions
- Expense tracking: salary, maintenance, infrastructure, miscellaneous
- Financial reports
- First-stage leave approval
- View payslips (read-only)

### EMPLOYEE — Pump Staff
- GPS check-in / check-out (geofence enforced)
- Shift handover: select replacement before checkout
- Apply for and view own leaves
- View own payslip and salary
- Enter fuel sold to customers (credit entry)
- Mark customer credit as settled (notification to SUPER_ADMIN + ADMIN)
- Enter meter readings for own shift
- Enter cash collected, online amount, miscellaneous expenses

---

## 3. Feature Modules

### Dashboard
| Role | Content |
|------|---------|
| PLATFORM_OWNER | All pumps, MRR, subscription statuses |
| SUPER_ADMIN | Daily sales, litres sold, cash+online, pending approvals, yearly analytics |
| ADMIN | Today's readings, pending handovers, leave approvals |
| ACCOUNTANT | Financial summary, credit settlements, expense overview |
| EMPLOYEE | Own attendance, shift status, lorry duty count |

### Attendance
- GPS location capture with accuracy display
- Geofence: if configured and outside radius → check-in hard blocked
- Shift handover: must select replacement + optional note
- WhatsApp sent to replacement on handover
- Monthly calendar: PRESENT / ABSENT / LATE / HALF_DAY / ON_LEAVE / PENALTY
- Confirmation required before check-in

### Leaves
- Types: PLANNED, EMERGENCY
- Approval flow: EMPLOYEE → ACCOUNTANT → SUPER_ADMIN/ADMIN
- Leave balance tracked per year (configurable paid leaves)
- Emergency leave: paid or unpaid (configurable)

### Meter Readings & Daily Sales
- 8 nozzles: 4 MS (Petrol) + 4 HSD (Diesel)
- Entry: today's end reading → system auto-calculates sale
- Daily report: litres per fuel type, expected revenue
- Cash + online payment per shift entered separately
- Variance tracked (actual vs expected cash)

### Credit Management
- Employee enters credit: customer name/account, amount
- Customer settles → employee marks settled → notification to management
- SUPER_ADMIN/ADMIN approves settlement
- Outstanding balance tracked per customer account

### Lorry Duty
- Assign duties to employees
- Employee accepts/refuses on device
- Lifecycle: SCHEDULED → ACCEPTED/REFUSED → DEPARTED → ARRIVED → COMPLETED
- WhatsApp notification on status change
- Incentive auto-linked to duty count

### Incentives & Finance
- Types: OIL_SALES, LUBRICANT_SALES, LORRY_DUTY, FESTIVAL_BONUS, PERFORMANCE, CUSTOM
- SUPER_ADMIN awards incentives; ACCOUNTANT views all

### Payslip
- Auto-generated monthly via pg_cron (1st of every month)
- Components: base salary + overtime + incentives + lorry duty bonus − leave deductions − loans
- Download or WhatsApp delivery

### Settings (SUPER_ADMIN only)
- Geo-fence: lat, lng, radius meters
- Shift: 12HR or 24HR, shift A/B start & end times
- Salary: DAILY_WAGES or MONTHLY_FIXED
- Leave: paid leaves/year, emergency leave policy
- WhatsApp: phone number ID, access token
- Reports: email, WhatsApp number

---

## 4. Database Schema

### Tables with pump_id (multi-tenant)

| Table | Purpose |
|-------|---------|
| `pumps` | Pump registry (PLATFORM_OWNER) |
| `users` | All users, all roles |
| `attendance` | Daily check-in/out records |
| `leaves` | Leave requests + approvals |
| `lorry_duties` | Duty assignments |
| `incentives` | Bonus records |
| `monthly_payslips` | Auto-generated payslips |
| `fuel_loads` | Fuel supply records |
| `shift_handovers` | Handover requests |
| `system_settings` | Per-pump operational config |
| `pump_payments` | Subscription payment history |

### Pumps Table Key Columns
```sql
id, name, address, city, state, country, pincode, phone, email,
pump_lat, pump_lng, geo_radius_meters,
subscription_status (TRIAL/ACTIVE/SUSPENDED/CANCELLED),
subscription_plan (BASIC/STANDARD/PREMIUM/ENTERPRISE),
monthly_premium, subscription_end,
whatsapp_enabled, reports_enabled, max_employees,
is_active, deactivated_at
```

### Role Enum
```sql
'PLATFORM_OWNER' | 'SUPER_ADMIN' | 'ADMIN' | 'ACCOUNTANT' | 'EMPLOYEE'
```

---

## 5. Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + TypeScript, Vite 4 |
| Styling | Tailwind CSS v3 |
| State | Zustand (persist) |
| Routing | React Router v6 |
| i18n | react-i18next (English + Hindi) |
| Backend | Supabase: PostgreSQL, Auth, Edge Functions |
| Cron | pg_cron: monthly payslip on 1st of month |
| Notifications | WhatsApp Cloud API (Meta Business) |
| Deployment | Vercel (PWA) + Supabase Cloud |

---

## 6. Project Structure

```
petrol-pump-management/
├── mobile-web/
│   └── src/
│       ├── pages/
│       │   ├── Login.tsx               Clean login, support number
│       │   ├── PlatformDashboard.tsx   PLATFORM_OWNER home
│       │   ├── PumpDetail.tsx          Create/edit pump + SUPER_ADMIN
│       │   ├── Dashboard.tsx           Pump-level home
│       │   ├── Attendance.tsx          GPS check-in/out
│       │   ├── Leaves.tsx              Leave management
│       │   ├── LorryDuty.tsx           Lorry assignments
│       │   ├── Incentives.tsx          Finance
│       │   ├── Employees.tsx           Staff management
│       │   ├── Payslip.tsx             Salary slips
│       │   └── Settings.tsx            Pump config
│       ├── components/
│       │   ├── BottomNav.tsx           Role-filtered navigation
│       │   └── ConfirmDialog.tsx       Confirmation modal
│       ├── hooks/
│       │   ├── useRoleAccess.ts        Permission matrix, 5 roles
│       │   └── useConfirm.ts           Promise-based confirm
│       └── stores/
│           └── useAuthStore.ts         Auth + pump_id
├── database/migrations/
│   ├── 001_phase1_employee_management.sql
│   ├── 002_pwa_complete_schema.sql
│   ├── 003_lorry_count_rpc.sql
│   ├── 004_mobile_web_fixes.sql
│   ├── 005_cron_payslip_automation.sql
│   └── 006_platform_owner_multitenancy.sql   ← pumps table + pump_id
└── supabase/functions/monthly-report/
```

---

## 7. Environment Setup

Create `mobile-web/.env.local`:
```env
VITE_SUPABASE_URL=https://aqtpuxjcotjukutezmbp.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
```

---

## 8. Running Locally

```bash
cd mobile-web
npm install
npm run dev          # http://localhost:3001
```

---

## 9. Deployment

```bash
# Frontend
cd mobile-web && npm run build
vercel --prod

# Edge function
supabase functions deploy monthly-report --project-ref aqtpuxjcotjukutezmbp
```

---

## 10. Database Migrations

Run in Supabase SQL Editor in order: 001 → 002 → 003 → 004 → 005 → 006

**After running 006 — set PLATFORM_OWNER:**
```sql
-- Update existing user:
UPDATE public.users
SET role = 'PLATFORM_OWNER', pump_id = NULL
WHERE email = 'mohitdwivedi746@gmail.com';

-- OR insert if not exists (replace <auth_uuid> from Supabase Auth panel):
INSERT INTO public.users
  (auth_id, email, first_name, last_name, role, is_active, is_blocked, pump_id)
VALUES
  ('<auth_uuid>', 'mohitdwivedi746@gmail.com', 'Mohit', 'Dwivedi', 'PLATFORM_OWNER', true, false, NULL)
ON CONFLICT (email) DO UPDATE SET role = 'PLATFORM_OWNER', pump_id = NULL;
```

---

## 11. Onboarding a New Petrol Pump

1. Log in as `mohitdwivedi746@gmail.com`
2. Tap **"Add New Petrol Pump"**
3. Fill: Name, City, State, Pincode, Phone, Email
4. Set Subscription Plan + Monthly Premium + Expiry Date
5. Toggle WhatsApp / Reports features
6. Tap **"Create Pump"**
7. Go to **Super Admin** tab → enter owner's name, email, phone + temporary password
8. Tap **"Create Super Admin Account"**
9. Share credentials securely with pump owner
10. Pump owner logs in → sees their pump's full operations dashboard immediately

---

## 12. Role Quick Reference Card

| Feature | PLATFORM OWNER | SUPER ADMIN | ADMIN | ACCOUNTANT | EMPLOYEE |
|---------|:-:|:-:|:-:|:-:|:-:|
| Platform dashboard | ✅ | ❌ | ❌ | ❌ | ❌ |
| Create / manage pumps | ✅ | ❌ | ❌ | ❌ | ❌ |
| Subscription management | ✅ | ❌ | ❌ | ❌ | ❌ |
| Operations dashboard | ❌ | ✅ | ✅ | ✅ | ✅ |
| Daily sales analytics | ❌ | ✅ | ✅ | ❌ | ❌ |
| Own attendance | ❌ | ✅ | ✅ | ❌ | ✅ |
| All staff attendance | ❌ | ✅ | ✅ | ❌ | ❌ |
| Leave approval | ❌ | ✅ | ✅ | ✅* | ❌ |
| Apply for leave | ❌ | ❌ | ❌ | ❌ | ✅ |
| Meter readings (enter) | ❌ | ✅ | ✅ | ❌ | ✅ |
| Credit management | ❌ | ✅ | ✅ | ✅ | ✅** |
| Lorry duty (manage) | ❌ | ✅ | ✅ | ❌ | ❌ |
| Lorry duty (own) | ❌ | ❌ | ❌ | ❌ | ✅ |
| Incentives (award) | ❌ | ✅ | ✅ | ❌ | ❌ |
| Incentives (view own) | ❌ | ✅ | ✅ | ✅ | ✅ |
| Payslip all employees | ❌ | ✅ | ✅ | ✅ | ❌ |
| Payslip own only | ❌ | ❌ | ❌ | ❌ | ✅ |
| Employee management | ❌ | ✅ | ✅ | ❌ | ❌ |
| Pump settings | ❌ | ✅ | ❌ | ❌ | ❌ |
| Financial reports | ❌ | ✅ | ❌ | ✅ | ❌ |
| WhatsApp send | ❌ | ✅ | ✅ | ❌ | ❌ |

> *ACCOUNTANT does first-stage leave approval only  
> **EMPLOYEE enters credit and marks settlement; SUPER_ADMIN/ADMIN approves
