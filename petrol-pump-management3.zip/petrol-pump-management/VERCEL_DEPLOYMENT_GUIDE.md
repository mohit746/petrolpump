# ⛽ PumpManager — Vercel Deployment Guide

> **App:** `mobile-web/` folder — React + Vite PWA connected to Supabase  
> **Time needed:** ~15 minutes  
> **Prerequisites:** GitHub account, Vercel account (free), Supabase project already set up

---

## 📋 Before You Start — Collect These Values

You will need these ready before deploying. Find them in your **Supabase Dashboard**:

| Value | Where to find it |
|---|---|
| `VITE_SUPABASE_URL` | Supabase → Project Settings → API → **Project URL** |
| `VITE_SUPABASE_ANON_KEY` | Supabase → Project Settings → API → **anon / public** key |

Example format:
```
VITE_SUPABASE_URL      = https://aqtpuxjcotjukutezmbp.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

---

## STEP 1 — Push Code to GitHub

### 1.1 Create a GitHub repository

1. Go to **https://github.com/new**
2. Repository name: `petrol-pump-management` (or any name you want)
3. Set to **Private** (recommended — your Supabase keys will be in env vars, not code)
4. Click **Create repository**
5. Copy the repository URL shown (e.g. `https://github.com/yourusername/petrol-pump-management.git`)

### 1.2 Push from your Mac terminal

Open Terminal and run these commands one by one:

```bash
cd /Users/dwivedm3/Documents/Learning/petrol-pump-management
git init
git add .
git commit -m "Initial deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git push -u origin main
```

> Replace `YOUR_USERNAME/YOUR_REPO_NAME` with your actual GitHub username and repo name from Step 1.1.

---

## STEP 2 — Deploy to Vercel

### 2.1 Open Vercel and import project

1. Go to **https://vercel.com**
2. Click **Sign Up** → choose **Continue with GitHub**
3. Authorize Vercel to access your GitHub
4. On the dashboard click **Add New → Project**
5. Find your `petrol-pump-management` repository and click **Import**

### 2.2 Configure the project settings

Vercel will show a configuration screen. Fill in **exactly** as follows:

| Field | Value to enter |
|---|---|
| **Framework Preset** | `Vite` |
| **Root Directory** | `mobile-web` |
| **Build Command** | `npm run build` |
| **Output Directory** | `dist` |
| **Install Command** | `npm install` |

> ⚠️ **Root Directory is the most important setting.** Click the pencil/edit icon next to it and type `mobile-web` — this tells Vercel to build from the `mobile-web` folder, not the project root.

### 2.3 Add Environment Variables

Still on the same configuration screen, scroll down to **Environment Variables** and add these **two** variables:

**Variable 1:**
```
Name:  VITE_SUPABASE_URL
Value: https://aqtpuxjcotjukutezmbp.supabase.co
```
*(Use your own Project URL from Supabase Settings → API)*

**Variable 2:**
```
Name:  VITE_SUPABASE_ANON_KEY
Value: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...  (your full anon key)
```
*(Use your own anon key from Supabase Settings → API)*

### 2.4 Deploy

Click the **Deploy** button. Vercel will:
1. Pull your code from GitHub
2. Run `npm install` inside `mobile-web/`
3. Run `npm run build` to create the `dist/` folder
4. Publish it to a live URL

Wait ~2 minutes. When it shows **"Congratulations!"** your app is live.

---

## STEP 3 — Get Your Live URL

After deployment you'll see a URL like:
```
https://petrol-pump-management-xyz.vercel.app
```

This is your app URL. **Share this with your Super Admin and staff** — they can install it as a PWA on their phones.

---

## STEP 4 — Configure Supabase Allowed URLs

To prevent auth errors, you must tell Supabase your live URL is allowed:

1. Go to **Supabase Dashboard** → **Authentication** → **URL Configuration**
2. Under **Site URL**, enter your Vercel URL:
   ```
   https://petrol-pump-management-xyz.vercel.app
   ```
3. Under **Redirect URLs**, add:
   ```
   https://petrol-pump-management-xyz.vercel.app/**
   ```
4. Click **Save**

---

## STEP 5 — Install as PWA on Phone (for staff)

The app is a **Progressive Web App (PWA)** — staff can install it on their phones like a native app:

### On iPhone (Safari):
1. Open the live URL in **Safari**
2. Tap the **Share** button (box with arrow) at the bottom
3. Scroll down and tap **Add to Home Screen**
4. Tap **Add**

### On Android (Chrome):
1. Open the live URL in **Chrome**
2. Tap the **three dots (⋮)** menu at the top right
3. Tap **Add to Home Screen** or **Install App**
4. Tap **Install**

The app will appear on the home screen with the PumpManager icon and work like a native app.

---

## STEP 6 — Future Updates (Redeploy)

Every time you make changes to the code and push to GitHub, Vercel will **automatically redeploy**. No manual steps needed.

```bash
# After making any code change:
cd /Users/dwivedm3/Documents/Learning/petrol-pump-management
git add .
git commit -m "Describe what you changed"
git push
```

Vercel picks up the push and deploys within ~2 minutes.

---

## 🔧 Troubleshooting

### Build fails — "Cannot find module" or similar
- Check that **Root Directory** is set to `mobile-web` in Vercel project settings
- Go to Vercel → Your Project → Settings → General → Root Directory

### App opens but shows blank white screen
- Environment variables are missing or wrong
- Go to Vercel → Your Project → Settings → Environment Variables
- Verify `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are correct
- After editing env vars, you must **Redeploy**: Vercel → Deployments → click the three dots on latest → Redeploy

### Login fails / "Invalid API key"
- Your `VITE_SUPABASE_ANON_KEY` value is wrong — copy it fresh from Supabase → Settings → API
- Make sure you copied the **anon** key, not the **service_role** key

### Auth redirect loops after login
- Supabase Site URL not set — complete Step 4 above

### App works on desktop but not on phone
- Make sure you're opening the URL in **Safari** (iPhone) or **Chrome** (Android)
- Other browsers on iPhone (Firefox, Chrome) don't fully support PWA install

---

## 📞 Vercel Project Settings Reference

To update settings after deployment:
1. Go to **https://vercel.com/dashboard**
2. Click your project
3. Click **Settings** tab
4. Key sections:
   - **General** → Root Directory, Build & Output Settings
   - **Environment Variables** → Add/edit your Supabase keys
   - **Domains** → Add a custom domain if you have one (e.g. `app.yourpumpname.com`)

---

## ✅ Deployment Checklist

- [ ] GitHub repository created and code pushed
- [ ] Vercel project created with Root Directory = `mobile-web`
- [ ] `VITE_SUPABASE_URL` environment variable added
- [ ] `VITE_SUPABASE_ANON_KEY` environment variable added
- [ ] Deployment succeeded (green checkmark in Vercel)
- [ ] Supabase Site URL updated with Vercel URL
- [ ] Logged in successfully on live URL
- [ ] Tested on mobile phone (PWA install)
