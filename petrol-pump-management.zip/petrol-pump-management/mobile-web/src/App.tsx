// src/App.tsx
import React, { useEffect } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import useAuthStore from './stores/useAuthStore'
import BottomNav from './components/BottomNav'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Attendance from './pages/Attendance'
import Leaves from './pages/Leaves'
import LorryDuty from './pages/LorryDuty'
import Payslip from './pages/Payslip'
import Employees from './pages/Employees'
import Incentives from './pages/Incentives'
import Settings from './pages/Settings'

const ProtectedLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useAuthStore()
  if (!isAuthenticated) return <Navigate to="/login" replace />
  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto pb-20">
        {children}
      </div>
      <BottomNav />
    </div>
  )
}

const App: React.FC = () => {
  const { initialize, isAuthenticated, isLoading } = useAuthStore()

  useEffect(() => { initialize() }, [initialize])

  if (isLoading) return (
    <div className="min-h-screen flex items-center justify-center bg-orange-50">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
        <p className="text-orange-600 font-medium text-sm">Loading...</p>
      </div>
    </div>
  )

  return (
    <Router>
      <Routes>
        <Route path="/login" element={isAuthenticated ? <Navigate to="/" replace /> : <Login />} />
        <Route path="/" element={<ProtectedLayout><Dashboard /></ProtectedLayout>} />
        <Route path="/attendance" element={<ProtectedLayout><Attendance /></ProtectedLayout>} />
        <Route path="/leaves" element={<ProtectedLayout><Leaves /></ProtectedLayout>} />
        <Route path="/lorry" element={<ProtectedLayout><LorryDuty /></ProtectedLayout>} />
        <Route path="/payslip" element={<ProtectedLayout><Payslip /></ProtectedLayout>} />
        <Route path="/employees" element={<ProtectedLayout><Employees /></ProtectedLayout>} />
        <Route path="/incentives" element={<ProtectedLayout><Incentives /></ProtectedLayout>} />
        <Route path="/settings" element={<ProtectedLayout><Settings /></ProtectedLayout>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  )
}

export default App
