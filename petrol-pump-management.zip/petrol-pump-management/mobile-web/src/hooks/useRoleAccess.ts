// src/hooks/useRoleAccess.ts
import useAuthStore from '../stores/useAuthStore'
import type { UserRole } from '../stores/useAuthStore'

const PERMISSIONS: Record<UserRole, string[]> = {
  SUPER_ADMIN: [
    'dashboard','attendance','leaves','lorry_duty','incentives','payslip',
    'employees','settings','reports','approve_leaves','manage_incentives','manage_lorry',
  ],
  ADMIN: [
    'dashboard','attendance','leaves','lorry_duty','incentives','payslip',
    'employees','approve_leaves','manage_incentives','manage_lorry',
  ],
  ACCOUNTANT: [
    'dashboard','attendance','leaves','payslip','approve_leaves_accountant',
  ],
  EMPLOYEE: [
    'dashboard','attendance','leaves','lorry_duty','payslip',
  ],
}

export function useRoleAccess() {
  const { user } = useAuthStore()
  const role = (user?.role || 'EMPLOYEE') as UserRole

  const can = (permission: string) => PERMISSIONS[role]?.includes(permission) ?? false
  const isAdmin     = role === 'SUPER_ADMIN' || role === 'ADMIN'
  const isSuperAdmin = role === 'SUPER_ADMIN'
  const isAccountant = role === 'ACCOUNTANT'

  return { can, isAdmin, isSuperAdmin, isAccountant, role }
}
