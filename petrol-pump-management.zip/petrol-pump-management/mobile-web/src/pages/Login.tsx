// src/pages/Login.tsx
import React, { useState } from 'react'
import { useTranslation } from 'react-i18next'
import { useForm } from 'react-hook-form'
import { EyeIcon, EyeSlashIcon } from '@heroicons/react/24/outline'
import toast from 'react-hot-toast'
import useAuthStore from '../stores/useAuthStore'

interface LoginForm { email: string; password: string }

const Login: React.FC = () => {
  const { t, i18n } = useTranslation()
  const { login, isLoading } = useAuthStore()
  const [showPw, setShowPw] = useState(false)
  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>()

  const onSubmit = async (data: LoginForm) => {
    const result = await login(data.email, data.password)
    if (result.success) toast.success(t('auth.success'))
    else toast.error(result.error || t('errors.server'))
  }

  const isHindi = i18n.language?.startsWith('hi')

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-orange-700 flex flex-col">
      {/* Language toggle */}
      <div className="flex justify-end p-4">
        <button
          onClick={() => i18n.changeLanguage(isHindi ? 'en' : 'hi')}
          className="px-4 py-2 bg-white/20 text-white rounded-full text-sm font-medium backdrop-blur-sm"
        >
          {t('lang.switch')}
        </button>
      </div>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-4">
        <div className="mb-8 text-center">
          <div className="h-20 w-20 bg-white rounded-3xl flex items-center justify-center mx-auto mb-4 shadow-xl">
            <span className="text-4xl">⛽</span>
          </div>
          <h1 className="text-3xl font-bold text-white">{t('app.name')}</h1>
          <p className="text-orange-100 text-sm mt-1">{t('app.tagline')}</p>
        </div>

        {/* Login card */}
        <div className="w-full max-w-sm bg-white rounded-3xl shadow-2xl p-6 space-y-4">
          <h2 className="text-lg font-bold text-gray-900 text-center">{t('auth.title')}</h2>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="label">{t('auth.email')}</label>
              <input
                type="email"
                className="input"
                placeholder="you@example.com"
                {...register('email', { required: t('errors.required') })}
              />
              {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="label">{t('auth.password')}</label>
              <div className="relative">
                <input
                  type={showPw ? 'text' : 'password'}
                  className="input pr-12"
                  placeholder="••••••••"
                  {...register('password', { required: t('errors.required') })}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"
                >
                  {showPw
                    ? <EyeSlashIcon className="h-5 w-5" />
                    : <EyeIcon className="h-5 w-5" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-red-500 mt-1">{errors.password.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full"
            >
              {isLoading
                ? <><span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />{t('auth.loggingIn')}</>
                : t('auth.loginBtn')}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

export default Login
