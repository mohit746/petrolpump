// src/pages/Dashboard.tsx
import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { format } from 'date-fns'
import {
  CalendarDaysIcon, TruckIcon, BanknotesIcon,
  ArrowRightOnRectangleIcon, GlobeAltIcon,
} from '@heroicons/react/24/outline'
import useAuthStore from '../stores/useAuthStore'
import { supabase } from '../lib/supabase'
import { useRoleAccess } from '../hooks/useRoleAccess'

interface TodayAttendance {
  check_in_time: string | null
  check_out_time: string | null
  status: string | null
}

const Dashboard: React.FC = () => {
  const { t, i18n } = useTranslation()
  const { user, logout } = useAuthStore()
  const { isAdmin, can } = useRoleAccess()

  const [todayAtt, setTodayAtt]       = useState<TodayAttendance | null>(null)
  const [pendingLeaves, setPendingLeaves] = useState(0)
  const [pendingLorry, setPendingLorry]   = useState(0)
  const [monthStats, setMonthStats]       = useState({ present: 0, absent: 0, earned: 0 })
  const [settings, setSettings]           = useState<{ shift_type: string; pump_name: string } | null>(null)

  const today = format(new Date(), 'yyyy-MM-dd')
  const isHindi = i18n.language?.startsWith('hi')

  useEffect(() => {
    if (!user) return

    // Today's attendance
    supabase.from('attendance').select('check_in_time, check_out_time, status')
      .eq('employee_id', user.id).eq('attendance_date', today).maybeSingle()
      .then(({ data }) => setTodayAtt(data))

    // Pending leaves (for admin: all pending; for employee: own pending)
    const leaveQ = supabase.from('leaves').select('id', { count: 'exact', head: true })
    if (isAdmin) leaveQ.in('status', ['PENDING_ACCOUNTANT', 'PENDING_SUPER_ADMIN'])
    else leaveQ.eq('employee_id', user.id).in('status', ['PENDING_ACCOUNTANT', 'PENDING_SUPER_ADMIN'])
    leaveQ.then(({ count }) => setPendingLeaves(count || 0))

    // Pending lorry duties
    const lorryQ = supabase.from('lorry_duties').select('id', { count: 'exact', head: true })
    if (isAdmin) lorryQ.eq('status', 'SCHEDULED')
    else lorryQ.eq('assigned_employee_id', user.id).eq('status', 'SCHEDULED')
    lorryQ.then(({ count }) => setPendingLorry(count || 0))

    // Month stats
    const monthStart = format(new Date(), 'yyyy-MM-01')
    supabase.from('attendance').select('status')
      .eq('employee_id', user.id).gte('attendance_date', monthStart).lte('attendance_date', today)
      .then(({ data }) => {
        const present = (data || []).filter(r => ['PRESENT', 'LATE'].includes(r.status)).length
        const absent  = (data || []).filter(r => r.status === 'ABSENT').length
        setMonthStats({ present, absent, earned: 0 })
      })

    // System settings
    supabase.from('system_settings').select('shift_type, pump_name').single()
      .then(({ data }) => setSettings(data))
  }, [user, today, isAdmin])

  const checkedIn  = !!todayAtt?.check_in_time
  const checkedOut = !!todayAtt?.check_out_time

  return (
    <div className="page">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white px-4 pt-12 pb-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-orange-100 text-sm">{settings?.pump_name || 'Petrol Pump'}</p>
            <h1 className="text-2xl font-bold mt-0.5">
              {t('dashboard.greeting', { name: user?.first_name })}
            </h1>
            <p className="text-orange-100 text-sm mt-1">
              {format(new Date(), 'EEEE, dd MMM yyyy')}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => i18n.changeLanguage(isHindi ? 'en' : 'hi')}
              className="bg-white/20 rounded-xl p-2 backdrop-blur-sm"
            >
              <GlobeAltIcon className="h-5 w-5" />
            </button>
            <button
              onClick={logout}
              className="bg-white/20 rounded-xl p-2 backdrop-blur-sm"
            >
              <ArrowRightOnRectangleIcon className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Check-in status pill */}
        <div className="mt-4">
          {checkedIn && !checkedOut
            ? <span className="bg-green-400/30 text-white text-sm px-4 py-1.5 rounded-full font-medium">
                ✓ {t('dashboard.checkedIn')} · {format(new Date(todayAtt!.check_in_time!), 'hh:mm a')}
              </span>
            : checkedOut
            ? <span className="bg-white/20 text-white text-sm px-4 py-1.5 rounded-full">
                ✓ Shift complete
              </span>
            : <span className="bg-red-400/30 text-white text-sm px-4 py-1.5 rounded-full font-medium">
                ● {t('dashboard.notCheckedIn')}
              </span>}
        </div>
      </div>

      <div className="page-content -mt-2">
        {/* Alert cards */}
        {pendingLeaves > 0 && (
          <Link to="/leaves" className="card p-4 flex items-center gap-3 bg-yellow-50 border-yellow-200">
            <CalendarDaysIcon className="h-6 w-6 text-yellow-600 flex-shrink-0" />
            <div className="flex-1">
              <p className="font-semibold text-yellow-800 text-sm">
                {isAdmin ? `${pendingLeaves} leave(s) awaiting approval` : `${pendingLeaves} leave(s) pending`}
              </p>
            </div>
            <span className="text-yellow-600 text-xs">→</span>
          </Link>
        )}

        {pendingLorry > 0 && (
          <Link to="/lorry" className="card p-4 flex items-center gap-3 bg-blue-50 border-blue-200">
            <TruckIcon className="h-6 w-6 text-blue-600 flex-shrink-0" />
            <div className="flex-1">
              <p className="font-semibold text-blue-800 text-sm">
                {isAdmin ? `${pendingLorry} lorry duty(ies) scheduled` : `You have ${pendingLorry} lorry duty scheduled`}
              </p>
            </div>
            <span className="text-blue-600 text-xs">→</span>
          </Link>
        )}

        {/* Quick actions */}
        <div>
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">{t('dashboard.quickActions')}</p>
          <div className="grid grid-cols-2 gap-3">
            {can('attendance') && (
              <Link to="/attendance" className="card p-4 flex flex-col items-center gap-2 text-center active:scale-95 transition-transform">
                <CalendarDaysIcon className="h-8 w-8 text-orange-500" />
                <span className="text-sm font-medium text-gray-700">{t('nav.attendance')}</span>
              </Link>
            )}
            {can('leaves') && (
              <Link to="/leaves" className="card p-4 flex flex-col items-center gap-2 text-center active:scale-95 transition-transform">
                <span className="text-3xl">🌴</span>
                <span className="text-sm font-medium text-gray-700">{t('nav.leaves')}</span>
              </Link>
            )}
            {can('lorry_duty') && (
              <Link to="/lorry" className="card p-4 flex flex-col items-center gap-2 text-center active:scale-95 transition-transform">
                <TruckIcon className="h-8 w-8 text-blue-500" />
                <span className="text-sm font-medium text-gray-700">{t('nav.lorry')}</span>
              </Link>
            )}
            {can('payslip') && (
              <Link to="/payslip" className="card p-4 flex flex-col items-center gap-2 text-center active:scale-95 transition-transform">
                <BanknotesIcon className="h-8 w-8 text-green-500" />
                <span className="text-sm font-medium text-gray-700">{t('nav.payslip')}</span>
              </Link>
            )}
          </div>
        </div>

        {/* Month stats */}
        <div>
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-3">{t('dashboard.myStats')}</p>
          <div className="grid grid-cols-3 gap-3">
            <div className="stat-card text-center">
              <span className="stat-value text-green-600">{monthStats.present}</span>
              <span className="stat-label">Present</span>
            </div>
            <div className="stat-card text-center">
              <span className="stat-value text-red-500">{monthStats.absent}</span>
              <span className="stat-label">Absent</span>
            </div>
            <div className="stat-card text-center">
              <span className="stat-value text-orange-500">{settings?.shift_type || '—'}</span>
              <span className="stat-label">Shift</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
