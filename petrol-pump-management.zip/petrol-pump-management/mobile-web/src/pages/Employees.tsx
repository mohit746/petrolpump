// src/pages/Employees.tsx
import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import toast from 'react-hot-toast'
import { PlusIcon, UserGroupIcon, MagnifyingGlassIcon } from '@heroicons/react/24/outline'
import { supabase } from '../lib/supabase'

interface Employee {
  id: string
  first_name: string
  last_name: string
  phone: string
  role: string
  is_active: boolean
  base_salary: number
  joining_date: string
  lorry_duty_count: number
}

const ROLES = ['EMPLOYEE', 'ACCOUNTANT', 'ADMIN']
const emptyForm = { first_name: '', last_name: '', phone: '', email: '', role: 'EMPLOYEE', base_salary: '', joining_date: '', password: '' }

const Employees: React.FC = () => {
  const { t } = useTranslation()
  const [employees, setEmployees] = useState<Employee[]>([])
  const [search, setSearch] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Employee | null>(null)
  const [form, setForm] = useState(emptyForm)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => { fetchEmployees() }, [])

  const fetchEmployees = async () => {
    const { data } = await supabase.from('users').select('id, first_name, last_name, phone, role, is_active, base_salary, joining_date, lorry_duty_count').order('first_name')
    setEmployees(data || [])
  }

  const filtered = employees.filter(e =>
    `${e.first_name} ${e.last_name} ${e.phone}`.toLowerCase().includes(search.toLowerCase())
  )

  const openAdd = () => { setEditing(null); setForm(emptyForm); setShowForm(true) }
  const openEdit = (e: Employee) => {
    setEditing(e)
    setForm({ first_name: e.first_name, last_name: e.last_name, phone: e.phone, email: '', role: e.role, base_salary: String(e.base_salary), joining_date: e.joining_date, password: '' })
    setShowForm(true)
  }

  const submit = async () => {
    if (!form.first_name || !form.last_name || !form.base_salary) { toast.error('Fill required fields'); return }
    setSubmitting(true)
    if (editing) {
      const { error } = await supabase.from('users').update({
        first_name: form.first_name, last_name: form.last_name, phone: form.phone,
        role: form.role, base_salary: parseFloat(form.base_salary), joining_date: form.joining_date,
      }).eq('id', editing.id)
      if (error) toast.error(error.message)
      else { toast.success(t('employees.updated')); setShowForm(false); fetchEmployees() }
    } else {
      // Create Supabase auth user first
      const { data: authData, error: authErr } = await supabase.auth.admin.createUser({
        email: form.email, password: form.password, email_confirm: true,
      })
      if (authErr) { toast.error(authErr.message); setSubmitting(false); return }
      const { error } = await supabase.from('users').insert({
        id: authData.user.id,
        first_name: form.first_name, last_name: form.last_name, phone: form.phone,
        role: form.role, base_salary: parseFloat(form.base_salary), joining_date: form.joining_date,
        is_active: true,
      })
      if (error) toast.error(error.message)
      else { toast.success(t('employees.created')); setShowForm(false); fetchEmployees() }
    }
    setSubmitting(false)
  }

  const toggleActive = async (emp: Employee) => {
    const { error } = await supabase.from('users').update({ is_active: !emp.is_active }).eq('id', emp.id)
    if (error) toast.error(error.message)
    else { toast.success(emp.is_active ? t('employees.deactivated') : t('employees.activated')); fetchEmployees() }
  }

  return (
    <div className="page">
      <div className="bg-white border-b px-4 pt-12 pb-4">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-xl font-bold text-gray-900">{t('nav.employees')}</h1>
          <button onClick={openAdd} className="flex items-center gap-1 text-sm text-orange-600 font-medium">
            <PlusIcon className="h-4 w-4" /> {t('employees.add')}
          </button>
        </div>
        <div className="relative">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} className="input pl-9" placeholder={t('employees.search')} />
        </div>
      </div>

      <div className="page-content">
        <p className="text-xs text-gray-400 font-medium">{filtered.length} {t('employees.total')}</p>
        {filtered.map(emp => (
          <div key={emp.id} className="list-item">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-gray-800">{emp.first_name} {emp.last_name}</p>
                  {!emp.is_active && <span className="badge-red text-xs">Inactive</span>}
                </div>
                <p className="text-xs text-gray-500">{emp.phone} · {emp.role}</p>
                <p className="text-xs text-gray-400">₹{emp.base_salary?.toLocaleString()} base · {emp.lorry_duty_count} lorry duties</p>
              </div>
              <div className="flex flex-col gap-1 items-end">
                <button onClick={() => openEdit(emp)} className="text-xs text-orange-600 border border-orange-200 rounded-lg px-2 py-1">{t('common.edit')}</button>
                <button onClick={() => toggleActive(emp)} className={`text-xs rounded-lg px-2 py-1 ${emp.is_active ? 'text-red-500 border-red-200 border' : 'text-green-600 border-green-200 border'}`}>
                  {emp.is_active ? t('employees.deactivate') : t('employees.activate')}
                </button>
              </div>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="text-center py-12 text-gray-400">
            <UserGroupIcon className="h-12 w-12 mx-auto mb-2 opacity-30" />
            <p>{t('employees.none')}</p>
          </div>
        )}
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-end">
          <div className="bg-white w-full rounded-t-3xl p-6 pb-safe max-h-[92vh] overflow-y-auto">
            <h2 className="text-lg font-bold text-gray-900 mb-4">{editing ? t('employees.editTitle') : t('employees.addTitle')}</h2>
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">{t('employees.firstName')} *</label>
                  <input value={form.first_name} onChange={e => setForm(f => ({ ...f, first_name: e.target.value }))} className="input" />
                </div>
                <div>
                  <label className="label">{t('employees.lastName')} *</label>
                  <input value={form.last_name} onChange={e => setForm(f => ({ ...f, last_name: e.target.value }))} className="input" />
                </div>
              </div>
              <div>
                <label className="label">{t('employees.phone')}</label>
                <input type="tel" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className="input" />
              </div>
              {!editing && (
                <>
                  <div>
                    <label className="label">{t('employees.email')} *</label>
                    <input type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className="input" />
                  </div>
                  <div>
                    <label className="label">{t('employees.password')} *</label>
                    <input type="password" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} className="input" />
                  </div>
                </>
              )}
              <div>
                <label className="label">{t('employees.role')}</label>
                <select value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} className="input">
                  {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="label">{t('employees.baseSalary')} (₹) *</label>
                <input type="number" value={form.base_salary} onChange={e => setForm(f => ({ ...f, base_salary: e.target.value }))} className="input" />
              </div>
              <div>
                <label className="label">{t('employees.joiningDate')}</label>
                <input type="date" value={form.joining_date} onChange={e => setForm(f => ({ ...f, joining_date: e.target.value }))} className="input" />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setShowForm(false)} className="btn-secondary flex-1">{t('common.cancel')}</button>
                <button onClick={submit} disabled={submitting} className="btn-primary flex-1">
                  {submitting ? t('common.loading') : t('common.save')}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Employees
