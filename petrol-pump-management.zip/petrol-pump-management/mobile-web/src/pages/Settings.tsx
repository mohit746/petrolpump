// src/pages/Settings.tsx
import React, { useEffect, useState } from 'react'
import { useTranslation } from 'react-i18next'
import toast from 'react-hot-toast'
import { MapPinIcon, Cog6ToothIcon } from '@heroicons/react/24/outline'
import { supabase } from '../lib/supabase'

interface Settings {
  pump_name: string
  shift_type: string
  salary_type: string
  paid_leaves_per_year: number
  half_day_threshold_hours: number
  penalty_multiplier: number
  geo_radius_meters: number
  pump_lat: number | null
  pump_lng: number | null
  whatsapp_phone_number_id: string
  whatsapp_access_token: string
  super_admin_whatsapp: string
}

const Settings: React.FC = () => {
  const { t } = useTranslation()
  const [settings, setSettings] = useState<Settings | null>(null)
  const [form, setForm] = useState<Partial<Settings>>({})
  const [saving, setSaving] = useState(false)
  const [gettingLoc, setGettingLoc] = useState(false)

  useEffect(() => {
    supabase.from('system_settings').select('*').single().then(({ data }) => {
      if (data) { setSettings(data); setForm(data) }
    })
  }, [])

  const save = async () => {
    setSaving(true)
    const { error } = await supabase.from('system_settings').update(form).eq('id', (settings as unknown as { id: string }).id)
    if (error) toast.error(error.message)
    else toast.success(t('settings.saved'))
    setSaving(false)
  }

  const captureLocation = () => {
    setGettingLoc(true)
    navigator.geolocation.getCurrentPosition(
      p => {
        setForm(f => ({ ...f, pump_lat: p.coords.latitude, pump_lng: p.coords.longitude }))
        toast.success(t('settings.locationCaptured'))
        setGettingLoc(false)
      },
      () => { toast.error(t('attendance.locationError')); setGettingLoc(false) },
      { enableHighAccuracy: true }
    )
  }

  const f = (key: keyof Settings, val: unknown) => setForm(prev => ({ ...prev, [key]: val }))

  if (!form.pump_name && !settings) return (
    <div className="page items-center justify-center">
      <Cog6ToothIcon className="h-10 w-10 text-gray-300 animate-spin" />
    </div>
  )

  return (
    <div className="page">
      <div className="bg-white border-b px-4 pt-12 pb-4">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-900">{t('nav.settings')}</h1>
          <button onClick={save} disabled={saving} className="btn-primary px-4 py-2 text-sm">
            {saving ? t('common.loading') : t('common.save')}
          </button>
        </div>
      </div>

      <div className="page-content">
        {/* General */}
        <div className="card p-4 space-y-4">
          <p className="font-semibold text-gray-700 text-sm">{t('settings.general')}</p>
          <div>
            <label className="label">{t('settings.pumpName')}</label>
            <input value={form.pump_name || ''} onChange={e => f('pump_name', e.target.value)} className="input" />
          </div>
          <div>
            <label className="label">{t('settings.shiftType')}</label>
            <div className="flex gap-2">
              {['12HR', '24HR'].map(s => (
                <button key={s} onClick={() => f('shift_type', s)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-medium border transition-colors ${form.shift_type === s ? 'bg-orange-500 text-white border-orange-500' : 'bg-white text-gray-600 border-gray-200'}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="label">{t('settings.salaryType')}</label>
            <div className="flex gap-2">
              {['DAILY_WAGES', 'MONTHLY_FIXED'].map(s => (
                <button key={s} onClick={() => f('salary_type', s)}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-medium border transition-colors ${form.salary_type === s ? 'bg-orange-500 text-white border-orange-500' : 'bg-white text-gray-600 border-gray-200'}`}>
                  {s === 'DAILY_WAGES' ? 'Daily' : 'Monthly'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Leave & Penalty */}
        <div className="card p-4 space-y-4">
          <p className="font-semibold text-gray-700 text-sm">{t('settings.leavePolicy')}</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">{t('settings.paidLeavesPerYear')}</label>
              <input type="number" value={form.paid_leaves_per_year || ''} onChange={e => f('paid_leaves_per_year', +e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">{t('settings.halfDayHours')}</label>
              <input type="number" value={form.half_day_threshold_hours || ''} onChange={e => f('half_day_threshold_hours', +e.target.value)} className="input" />
            </div>
          </div>
          <div>
            <label className="label">{t('settings.penaltyMultiplier')} (×)</label>
            <input type="number" step="0.5" value={form.penalty_multiplier || ''} onChange={e => f('penalty_multiplier', +e.target.value)} className="input" />
            <p className="text-xs text-gray-400 mt-1">2 = double daily salary deduction for unapproved absence</p>
          </div>
        </div>

        {/* Geo-fence */}
        <div className="card p-4 space-y-4">
          <p className="font-semibold text-gray-700 text-sm">{t('settings.geoFence')}</p>
          <div>
            <label className="label">{t('settings.geoRadius')} (meters)</label>
            <input type="number" value={form.geo_radius_meters || ''} onChange={e => f('geo_radius_meters', +e.target.value)} className="input" />
          </div>
          {form.pump_lat && form.pump_lng ? (
            <div className="bg-green-50 border border-green-200 rounded-xl p-3">
              <p className="text-sm text-green-700 font-medium flex items-center gap-1">
                <MapPinIcon className="h-4 w-4" /> {t('settings.pumpLocation')}
              </p>
              <p className="text-xs text-green-600 mt-1">{form.pump_lat?.toFixed(6)}, {form.pump_lng?.toFixed(6)}</p>
            </div>
          ) : (
            <p className="text-sm text-gray-400">{t('settings.noLocation')}</p>
          )}
          <button onClick={captureLocation} disabled={gettingLoc} className="btn-secondary w-full">
            <MapPinIcon className="h-4 w-4 inline mr-1.5" />
            {gettingLoc ? t('common.loading') : t('settings.captureLocation')}
          </button>
        </div>

        {/* WhatsApp */}
        <div className="card p-4 space-y-4">
          <p className="font-semibold text-gray-700 text-sm">{t('settings.whatsapp')}</p>
          <div>
            <label className="label">{t('settings.waPhoneNumberId')}</label>
            <input value={form.whatsapp_phone_number_id || ''} onChange={e => f('whatsapp_phone_number_id', e.target.value)} className="input font-mono text-sm" placeholder="1234567890" />
          </div>
          <div>
            <label className="label">{t('settings.waAccessToken')}</label>
            <input type="password" value={form.whatsapp_access_token || ''} onChange={e => f('whatsapp_access_token', e.target.value)} className="input font-mono text-sm" placeholder="EAAxx..." />
          </div>
          <div>
            <label className="label">{t('settings.superAdminWhatsapp')}</label>
            <input type="tel" value={form.super_admin_whatsapp || ''} onChange={e => f('super_admin_whatsapp', e.target.value)} className="input" placeholder="+919876543210" />
          </div>
        </div>

        <button onClick={save} disabled={saving} className="btn-primary w-full py-4 text-base">
          {saving ? t('common.loading') : t('settings.saveAll')}
        </button>
      </div>
    </div>
  )
}

export default Settings
