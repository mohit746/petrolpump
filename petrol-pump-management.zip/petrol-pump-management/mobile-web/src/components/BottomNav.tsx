// src/components/BottomNav.tsx
import React from 'react'
import { NavLink } from 'react-router-dom'
import { useTranslation } from 'react-i18next'
import {
  HomeIcon, CalendarDaysIcon, TruckIcon,
  BanknotesIcon, UsersIcon, Cog6ToothIcon,
} from '@heroicons/react/24/outline'
import {
  HomeIcon as HomeSolid, CalendarDaysIcon as CalSolid, TruckIcon as TruckSolid,
  BanknotesIcon as BankSolid, UsersIcon as UsersSolid, Cog6ToothIcon as CogSolid,
} from '@heroicons/react/24/solid'
import { useRoleAccess } from '../hooks/useRoleAccess'

const BottomNav: React.FC = () => {
  const { t } = useTranslation()
  const { can, isAdmin } = useRoleAccess()

  const tabs = [
    { to: '/dashboard', label: t('nav.dashboard'),   Icon: HomeIcon,          ActiveIcon: HomeSolid,   always: true },
    { to: '/attendance', label: t('nav.attendance'), Icon: CalendarDaysIcon,  ActiveIcon: CalSolid,    perm: 'attendance' },
    { to: '/lorry',      label: t('nav.lorry'),      Icon: TruckIcon,         ActiveIcon: TruckSolid,  perm: 'lorry_duty' },
    { to: '/payslip',   label: t('nav.payslip'),     Icon: BanknotesIcon,     ActiveIcon: BankSolid,   perm: 'payslip' },
    { to: '/employees', label: t('nav.employees'),   Icon: UsersIcon,         ActiveIcon: UsersSolid,  adminOnly: true },
    { to: '/settings',  label: t('nav.settings'),    Icon: Cog6ToothIcon,     ActiveIcon: CogSolid,    superOnly: true },
  ].filter(tab => {
    if (tab.always) return true
    if (tab.adminOnly) return isAdmin
    if (tab.superOnly) return can('settings')
    if (tab.perm) return can(tab.perm)
    return true
  })

  return (
    <nav className="tab-bar">
      {tabs.map(({ to, label, Icon, ActiveIcon }) => (
        <NavLink
          key={to}
          to={to}
          className={({ isActive }) => `tab-item${isActive ? ' active' : ''}`}
        >
          {({ isActive }) => (
            <>
              {isActive
                ? <ActiveIcon className="h-6 w-6" />
                : <Icon className="h-6 w-6" />}
              <span className="text-[10px] font-medium leading-tight">{label}</span>
            </>
          )}
        </NavLink>
      ))}
    </nav>
  )
}

export default BottomNav
