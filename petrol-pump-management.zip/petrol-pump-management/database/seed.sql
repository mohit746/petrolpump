-- Seed data for Petrol Pump Management System
-- Run this after schema.sql

-- Insert default admin user (you'll need to update with actual auth_id from Supabase)
INSERT INTO public.users (auth_id, email, username, first_name, last_name, phone, role) VALUES
('00000000-0000-0000-0000-000000000000', 'admin@petrolpump.com', 'admin', 'System', 'Administrator', '+919999999999', 'OWNER');

-- Insert sample dispensing units
INSERT INTO public.dispensing_units (unit_number, fuel_type, rate_per_liter, description) VALUES
('Nozzle-1A', 'MS', 102.50, 'Motor Spirit Dispenser 1A'),
('Nozzle-1B', 'MS', 102.50, 'Motor Spirit Dispenser 1B'),
('Nozzle-2A', 'HSD', 89.75, 'High Speed Diesel Dispenser 2A'),
('Nozzle-2B', 'HSD', 89.75, 'High Speed Diesel Dispenser 2B'),
('Lub-Counter', 'LUBRICANT', 450.00, 'Lubricant Sales Counter'),
('Oil-Counter', 'ENGINE_OIL_2T', 380.00, '2T Engine Oil Sales Counter');

-- Insert sample staff users (you'll need to update with actual auth_ids)
INSERT INTO public.users (auth_id, email, username, first_name, last_name, phone, role) VALUES
('00000000-0000-0000-0000-000000000001', 'manager@petrolpump.com', 'manager1', 'Raj', 'Kumar', '+919999999998', 'MANAGER'),
('00000000-0000-0000-0000-000000000002', 'supervisor@petrolpump.com', 'supervisor1', 'Priya', 'Sharma', '+919999999997', 'SUPERVISOR'),
('00000000-0000-0000-0000-000000000003', 'cashier1@petrolpump.com', 'cashier1', 'Amit', 'Singh', '+919999999996', 'CASHIER'),
('00000000-0000-0000-0000-000000000004', 'cashier2@petrolpump.com', 'cashier2', 'Sunita', 'Devi', '+919999999995', 'CASHIER');

-- Insert a sample shift for demonstration
INSERT INTO public.shifts (user_id, start_time, status) 
SELECT id, NOW() - INTERVAL '2 hours', 'ACTIVE' 
FROM public.users 
WHERE username = 'cashier1' 
LIMIT 1;

-- Insert sample reading entries for the shift
WITH shift_data AS (
  SELECT s.id as shift_id, u.id as user_id
  FROM public.shifts s
  JOIN public.users u ON s.user_id = u.id
  WHERE u.username = 'cashier1' AND s.status = 'ACTIVE'
  LIMIT 1
)
INSERT INTO public.reading_entries (dispensing_unit_id, shift_id, previous_reading, current_reading, rate_per_liter, entry_type, entered_by)
SELECT 
  du.id,
  sd.shift_id,
  1000.00, -- Previous reading
  1000.00, -- Current reading (same as previous for shift start)
  du.rate_per_liter,
  'SHIFT_START',
  sd.user_id
FROM public.dispensing_units du
CROSS JOIN shift_data sd
WHERE du.fuel_type IN ('MS', 'HSD');

-- Insert today's daily summary placeholder
INSERT INTO public.daily_summaries (date, total_fuel_sold, total_revenue, total_cash_collected, total_variance, number_of_shifts)
VALUES (CURRENT_DATE, 0.00, 0.00, 0.00, 0.00, 0)
ON CONFLICT (date) DO NOTHING;