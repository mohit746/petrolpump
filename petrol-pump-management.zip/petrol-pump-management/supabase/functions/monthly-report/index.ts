// supabase/functions/monthly-report/index.ts
// Triggered on 1st of each month via pg_cron or Supabase cron schedule
// Schedule: "0 6 1 * *" (6 AM on 1st of every month)

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )

    // Determine last month
    const now = new Date()
    const reportMonth = now.getMonth() === 0 ? 12 : now.getMonth()
    const reportYear = now.getMonth() === 0 ? now.getFullYear() - 1 : now.getFullYear()

    // Get all active employees
    const { data: employees, error: empErr } = await supabase
      .from('users').select('id, first_name, last_name, base_salary, role')
      .eq('is_active', true)
    if (empErr) throw empErr

    // Get system settings for WhatsApp + salary rules
    const { data: settings } = await supabase.from('system_settings').select('*').single()

    const monthStart = `${reportYear}-${String(reportMonth).padStart(2, '0')}-01`
    const monthEnd = new Date(reportYear, reportMonth, 0).toISOString().split('T')[0]

    const payslipSummary: string[] = []
    let totalPayout = 0

    for (const emp of employees || []) {
      // Get attendance for the month
      const { data: attendance } = await supabase.from('attendance')
        .select('status, check_in_time, check_out_time')
        .eq('employee_id', emp.id)
        .gte('attendance_date', monthStart)
        .lte('attendance_date', monthEnd)

      const daysPresent = (attendance || []).filter(a => ['PRESENT', 'LATE'].includes(a.status)).length
      const halfDays = (attendance || []).filter(a => a.status === 'HALF_DAY').length
      const daysAbsent = (attendance || []).filter(a => a.status === 'ABSENT').length
      const penaltyDays = (attendance || []).filter(a => a.status === 'PENALTY').length

      // Get total days in month
      const totalDays = new Date(reportYear, reportMonth, 0).getDate()

      // Calculate daily rate
      const salaryType = settings?.salary_type || 'DAILY_WAGES'
      const dailyRate = salaryType === 'DAILY_WAGES'
        ? emp.base_salary
        : emp.base_salary / totalDays

      // Calculate basic
      const effectiveDays = daysPresent + (halfDays * 0.5)
      const basicEarned = salaryType === 'DAILY_WAGES'
        ? effectiveDays * dailyRate
        : emp.base_salary - (daysAbsent * dailyRate)

      // Get incentives
      const { data: incentives } = await supabase.from('incentives')
        .select('amount').eq('employee_id', emp.id)
        .gte('incentive_date', monthStart).lte('incentive_date', monthEnd)
      const totalIncentives = (incentives || []).reduce((s, i) => s + i.amount, 0)

      // Penalty deductions
      const penaltyMultiplier = settings?.penalty_multiplier || 2
      const penaltyDeduction = penaltyDays * dailyRate * penaltyMultiplier

      // Lorry allowances
      const { data: lorries } = await supabase.from('lorry_duties')
        .select('allowance_amount').eq('assigned_employee_id', emp.id)
        .eq('status', 'COMPLETED').gte('scheduled_date', monthStart).lte('scheduled_date', monthEnd)
      const lorryAllowance = (lorries || []).reduce((s, l) => s + (l.allowance_amount || 0), 0)

      const netSalary = Math.max(0, basicEarned + totalIncentives + lorryAllowance - penaltyDeduction)
      totalPayout += netSalary

      // Upsert payslip
      await supabase.from('monthly_payslips').upsert({
        employee_id: emp.id,
        month: reportMonth,
        year: reportYear,
        days_present: daysPresent,
        days_absent: daysAbsent,
        half_days: halfDays,
        basic_salary: Math.round(basicEarned),
        total_incentives: Math.round(totalIncentives),
        lorry_allowances: Math.round(lorryAllowance),
        total_deductions: Math.round(penaltyDeduction),
        net_salary: Math.round(netSalary),
        generated_at: new Date().toISOString(),
      }, { onConflict: 'employee_id,month,year' })

      payslipSummary.push(`${emp.first_name} ${emp.last_name}: ₹${Math.round(netSalary).toLocaleString()}`)
    }

    // Send WhatsApp to super admin
    if (settings?.whatsapp_phone_number_id && settings?.whatsapp_access_token && settings?.super_admin_whatsapp) {
      const monthName = new Date(reportYear, reportMonth - 1, 1).toLocaleString('en', { month: 'long' })
      const message = [
        `📊 *Monthly Report - ${monthName} ${reportYear}*`,
        ``,
        `Total Employees: ${employees?.length}`,
        `Total Payout: ₹${Math.round(totalPayout).toLocaleString()}`,
        ``,
        `*Individual Payslips:*`,
        ...payslipSummary.slice(0, 10),
        payslipSummary.length > 10 ? `...and ${payslipSummary.length - 10} more` : '',
        ``,
        `View full report in PumpManager app.`,
      ].filter(Boolean).join('\n')

      await fetch(`https://graph.facebook.com/v18.0/${settings.whatsapp_phone_number_id}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${settings.whatsapp_access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: settings.super_admin_whatsapp.replace(/\D/g, ''),
          type: 'text',
          text: { body: message },
        }),
      })

      // Log notification
      await supabase.from('notification_log').insert({
        recipient_phone: settings.super_admin_whatsapp,
        message_type: 'MONTHLY_REPORT',
        message_body: message,
        status: 'SENT',
        sent_at: new Date().toISOString(),
      })
    }

    return new Response(JSON.stringify({
      success: true,
      month: reportMonth,
      year: reportYear,
      employeesProcessed: employees?.length,
      totalPayout: Math.round(totalPayout),
    }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 })

  } catch (error) {
    console.error('Monthly report error:', error)
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500
    })
  }
})
